AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
include('shared.lua');
  
function ENT:OnTakeDamage(dmg)
	self:SetHealth(self:Health() - dmg:GetDamage())
	if self:Health() <= 0 then --run on death
		Msg("Dead\n");
		self:SetSchedule( SCHED_FALL_TO_GROUND ) --because it's given a new schedule, the old one will end.
	end
	local attacker = dmg:GetAttacker();
	if (attacker:GetClass() == "player") then
		self:AddAttacker(attacker);
	end
end
  
function ENT:SelectSchedule()
	-- modify to go after shields/zpm and increase power output
	self:StartSchedule(self:Move(self:FindTech()));
end
