AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
include('shared.lua');
  
function ENT:OnTakeDamage(dmg)
	local att = dmg:GetAttacker();
	local dam = dmg:GetDamage();
	self:SetHealth(self:Health() - dam);
	if (self:Health() <= 0) then
		self:RemoveRep(self);
		self:Remove();
		-- half the blocks if shot or explosion under 100 damage or crossbow which = 100
		-- otherwise it is completely destroyed
		if (dmg:IsBulletDamage() or (dmg:IsExplosionDamage() and dam < 100) or dam == 100) then
			self:SpawnX(cost[1]/2,"replicator_block");
		end
	end
	if (att:GetClass() == "player") then
		self:AddAttacker(att);
		if (self.leader ~= nil) then
			self:AttackCode("lead", self.leader.group);
		else
			self:AttackCode();
		end
	end
end
  
function ENT:SelectSchedule()	
	if (self.attack) then --works for 1st in list only
		self:StartSchedule(self:Move(self:AttackWho()));
	else
		if (self.leader == nil or !self.leader:IsValid()) then
			self:StartSchedule(self:Move(self:Find("prop_physics"),0));
		end
	end
end
