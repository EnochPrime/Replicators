SWEP.PrintName = "ARG";
SWEP.Author = "JDM12989";
SWEP.Contact = "";
SWEP.Purpose = "Pwning Replicators";
SWEP.Instructions = "";
SWEP.Base = "weapon_base";
SWEP.Slot = 0;
SWEP.SlotPos = 1;
SWEP.DrawAmmo	= true;
SWEP.DrawCrosshair = true;
SWEP.ViewModel = "models/weapons/v_physcannon.mdl";
SWEP.WorldModel = "models/weapons/w_physcannon.mdl";

-- primary
SWEP.Primary.Clipsize = 1
SWEP.Primary.DefaultClip = 1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

-- secondary
SWEP.Secondary.Clipsize = 1
SWEP.Secondary.DefaultClip = 1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "GaussEnergy" 

-- spawnables
SWEP.Spawnable = true;
SWEP.AdminSpawnable = false;

--################### Dummys for the client @ 
function SWEP:PrimaryAttack() return false end;
function SWEP:SecondaryAttack() return false end;

-- to cancel out default reload function
function SWEP:Reload() return; end