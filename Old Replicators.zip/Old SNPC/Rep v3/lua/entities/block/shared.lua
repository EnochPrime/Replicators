ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Replicator Block"
ENT.Author			= "JDM12989"
ENT.Category		= "Stargate"

ENT.Spawnable			= true;
ENT.AdminSpawnable		= true;

ENT.model = "models/props_junk/popcan01a.mdl";