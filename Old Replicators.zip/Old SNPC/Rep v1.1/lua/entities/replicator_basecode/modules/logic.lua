include('attack.lua');
include('move.lua');
include('scavenge.lua');
include('vars.lua');

function ENT:Command()
	if (self.attack) then --attack is not working!!
		self:StartSchedule(self:Move(self:AttackWho()));
		return "attack";
	else
		self:StartSchedule(self:Move(self:FindMat()));
		return "scavenge";
	end
end
