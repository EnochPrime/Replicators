AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
include('shared.lua');

function ENT:SpawnFunction(ply, tr)
	if (!tr.Hit) then return end
	local SpawnPos = tr.HitPos + tr.HitNormal * 16;
	local ent = ents.Create("replicator");
	ent:SetPos(SpawnPos);
	ent:Spawn();
	ent:Activate();
	return ent;
end

function ENT:Think()
	if (self.ThinkNext > CurTime()) then return end
	if (!self:Dial()) then
		if (!self.attack) then
			self:Collect();
			self:Replicate();
		else
			self:Attack();
		end
	else
		self:GateDial();
	end
	self.NextThink = CurTime()+1;
end

function ENT:OnTakeDamage(dmg)
	self:Remove();
	local new = self:SpawnX(self:Count(self:GetClass()),"replicator_block");
	local blocks_removed = math.Round(dmg:GetDamage() / self.health);
	self:FadeX(blocks_removed,new);
	self:AttackAdd(dmg:GetAttacker());
end

function ENT:Touch(ent)
	if (ent:GetClass() == "prop_physics") then
		gcombat.nrghit(ent, 10, 0, self:GetPos(), ent:GetPos());
		self.mat = self.mat + 10;	
	end
	if (self.attack and ent:GetClass() == "player") then
		ent:TakeDamage(10,self);
	end
end
