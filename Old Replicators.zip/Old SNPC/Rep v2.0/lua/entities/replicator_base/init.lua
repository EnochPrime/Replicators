AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
include('shared.lua');
include('modules/assemble.lua');
include('modules/spawner.lua');

function ENT:Initialize()
	self:SetModel(self.model);
	self:PhysicsInit(SOLID_VPHYSICS);
	self:SetMoveType(MOVETYPE_VPHYSICS);
	self:SetSolid(SOLID_VPHYSICS);
	
	self.assembled = false;
	self.attack = false;
	self.health = 10;
	self.linked = nil;
	self.mat = 0;
	self.matreq = 100;
	self.sever = false;
	self.speed = 2500;
	self.wait = CurTime();
	
	self.ThinkNext = CurTime()+1;
	local phys = self:GetPhysicsObject();
	if (phys:IsValid()) then
		phys:Wake();
	end
end

function ENT:Gather()
	self:Link();
	local blocks_near = {};
	local maxdist = 0;
	local vdist = 0;
	
	blocks_near = ents.FindByClass("replicator_block");
	maxdist = 100;
	mindist = 30;
	local closest = nil;
	if (self.linked != {}) then
		for l,b in pairs (self.linked) do
			for k,v in pairs (blocks_near) do
				if (b != v and !v.sever) then
					vdist = (v:GetPos() - self:GetPos()):Length();
					if (vdist > mindist and vdist < maxdist) then
						maxdist = vdist;
						closest = v;
					end
				end
			end
		end
	else
		for k,v in pairs(blocks_near) do
			vdist = (v:GetPos() - self:GetPos()):Length();
			if (vdist < maxdist and vdist != 0 and !v.sever) then
				maxdist = vdist;
				closest = v;
			end
		end
	end
	if (closest != nil and closest:IsValid()) then
		local vec = ((closest:GetPos()-self:GetPos()):Normalize()*25);
		self:GetPhysicsObject():ApplyForceCenter(vec);
		if (self.linked != {}) then
			for k,v in pairs (self.linked) do
				vec = ((closest:GetPos()-self:GetPos()):Normalize()*25);
				v:GetPhysicsObject():ApplyForceCenter(vec);
			end
		end
	end
end	

function ENT:Link()
	self.linked = {self.Entity};
	local newgroup = ents.FindByClass("replicator_block");
	local maxdist = 5;
	local close = nil;
	for k,v in pairs (newgroup) do
		if (v.Entity != ent and !v.sever) then
			local vdist = (v:GetPos() - self:GetPos()):Length();
			if (vdist < maxdist and vdist != 0) then
				maxdist = vdist;
				close = v;
			end
		end
	end
	if (close != nil and close:IsValid()) then
		table.insert(self.linked,close);
	end
end
