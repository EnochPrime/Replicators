local schdFollow = ai_schedule.New();

--[[schdFollow:EngTask("TASK_TARGET_PLAYER",0);
schdFollow:EngTask("TASK_GET_PATH_TO_TARGET",0);]]
schdFollow:AddTask("Follow",{Class = "player", Radius = 10000});
schdFollow:EngTask("TASK_GET_PATH_TO_LASTPOSITION",0);
schdFollow:EngTask("TASK_FACE_PATH",0);
schdFollow:EngTask("TASK_WALK_PATH_WITHIN_DIST",50);
--schdFollow:EngTask("TASK_WAIT_FOR_MOVEMENT",0);
schdFollow:EngTask("TASK_STOP_MOVING",0);
schdFollow:AddTask("Loop");

function ENT:Task_Follow(data)
end

function ENT:TaskStart_Follow(data)
	self:TaskComplete();
	Msg("task start\n");
	if (self.follow and self.follow:IsValid() and (self:GetPos()-self.follow:GetPos()):Length() < 50) then
		Msg("following\n");
		return;
	end
	
	--local leader = ents.FindInSphere(self:GetPos(),data.Radius);
	local leader = ents.FindByClass(data.Class);
	Msg("begin check\n");
	for _,v in pairs (leader) do
		if (v:IsValid() and v:GetClass() == data.Class) then
			self:SetLastPosition(v:GetPos() + Vector(0,0,25));
			self.follow = v;
			Msg("target set\n");
		end
	end
	--self:SetSchedule(schdFollow);
	--self:TaskComplete();
	Msg("task complete\n");
end

function ENT:Task_Loop(data)
end

function ENT:TaskStart_Loop(data)
	self:TaskComplete();
	self:SetSchedule(schdFollow);
end

function ENT:Follow()
	return schdFollow;
end
