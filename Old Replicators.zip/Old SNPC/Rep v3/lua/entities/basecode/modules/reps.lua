rep_list = {};
rep_avail = {};

function ENT:AddRep()
	table.insert(rep_list,self);
	if (self:GetClass() == "npc_rep") then
		self:SetAvail(self,true);
	end
end

function ENT:RemoveRep()
	for k,v in pairs(rep_list) do
		if (v == self) then
			table.remove(rep_list,k);
			v:SetAvail(self,false);
		end
	end
end

function ENT:SetAvail(ent,bool)
	if(bool) then
		table.insert(rep_avail,ent);
		ent.leader = nil;
	else
		for k,v in pairs(rep_avail) do
			if (v == ent) then
				table.remove(rep_avail,k);
			end
		end
	end
end
