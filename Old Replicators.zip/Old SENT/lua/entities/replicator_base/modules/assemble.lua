include('vars.lua');

function ENT:Assemble(typ)
	local blocks_closest = {};
	blocks_near = ents.FindByClass("replicator_block");
	maxdist = 20;
	for k,v in pairs(blocks_near) do
		vdist = (v:GetPos() - self:GetPos()):Length();
		if (vdist < maxdist) then
			table.insert(blocks_closest,v);
		end
	end
	if (table.Count(blocks_closest) >= self:Count(typ)) then
		if (!self.assembled) then
			self:SpawnX(1,typ);
			for var = 1, self:Count(typ), 1 do
				blocks_closest[var].assembled = true;
				blocks_closest[var]:Remove();
			end
		end
	end
end	