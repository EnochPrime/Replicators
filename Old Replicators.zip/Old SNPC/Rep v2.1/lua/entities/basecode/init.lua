AddCSLuaFile("shared.lua");
include('shared.lua');
include('modules/activity.lua');
include('modules/find.lua');
include('modules/move.lua');
include('modules/spawner.lua');
include('modules/vars.lua');

function ENT:Initialize()
	self:SetModel(self.model);
	self:SetHullType(self.hull);
	self:SetHullSizeNormal();
	self:SetSolid(SOLID_BBOX);
	self:SetMoveType(MOVETYPE_STEP);
	self:CapabilitiesAdd(CAP_MOVE_GROUND);
	self:SetMaxYawSpeed(5000);
	self:SetHealth(self.health);
	self:AddRep(self);
	self.attack = false;
	self.leader = nil;
	self.mat = 0;
	--self.shield = false;
	--following 2 should only be applied to large rep
	--LS_RegisterEnt(self);
	--RD_AddResource(self, "energy", 100000000);
end
