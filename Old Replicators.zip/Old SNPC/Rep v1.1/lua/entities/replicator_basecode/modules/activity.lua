include('spawner.lua');

function ENT:Activity(ent)
	Msg("Activity\n");
	local class = ent:GetClass();
	if (class == "player") then
		-- hurt
		Msg("hurt\n");
		ent:TakeDamage(1,self);
	else
		gcombat.devhit(ent,10,20,true);
		--material increase
		self.material = self.material + 10;
		if (self.material >= 100) then
			Msg("enough\n");
			-- replication code, temp!
			self:SpawnX(1,"replicator_standard");
			self.material = self.material - 100;
		end
	end
end
