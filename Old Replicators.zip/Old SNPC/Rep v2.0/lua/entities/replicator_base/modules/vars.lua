local countreq = {20};

function ENT:Count(str)
	if (str == "npc_rep") then
		return 20;
	else
		return 0;
	end
end
