AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
include('shared.lua');
  
function ENT:OnTakeDamage(dmg)
	local att = dmg:GetAttacker();
	local dam = dmg:GetDamage();
	self:SetHealth(self:Health() - dam);
	Msg(dam .. "\n");
	if (self:Health() <= 0) then
		self:RemoveRep(self);
		self:Remove();
		-- half the blocks if shot or explosion under 100 damage or crossbow which = 100
		-- otherwise it is completely destroyed
		if (dmg:IsBulletDamage() or (dmg:IsExplosionDamage() and dam < 100) or dam == 100) then
			self:SpawnX(cost[1]/2,"replicator_block");
		end
	end
	if (att:GetClass() == "player") then
		self:AddAttacker(att);
	end
end
  
function ENT:SelectSchedule()
	--[[if ((#replicators * cost[1]) > ((cost[3]/cost[1])*2)) then
		Msg("human\n");
	end]]
	
	if (self.attack) then --works for 1st in list only
		self:StartSchedule(self:Move(self:AttackWho()));
	else
		if (self.leader == nil or !self.leader:IsValid()) then
			self:StartSchedule(self:Move(self:Find("prop_physics")));
		end
	end
end
