blocks = {};

function ENT:AddBlock()
	table.insert(blocks,self);
end

function ENT:RemoveBlock()
	for k,v in pairs(blocks) do
		if (v == self) then
			table.remove(blocks,k);
		end
	end
end

function ENT:Check()
	local b = true;
	for k,v in pairs(blocks) do
		if (v == nil or not v:IsValid() or v.sever) then
			table.remove(blocks,k);
		end
		if (v.leader == nil) then
			for l,w in pairs(blocks) do
				if (w.leader == w) then
					v.leader = w;
				end
			end
		else
			b = false;
		end
	end
	if (b) then
		blocks[1].leader = blocks[1];
	end
end
