include('vars.lua');

local tbl_freq = nil;
local tbl_remember = {0,0,0,0};

function ENT:Disassemble(typ,from,to,num)
	if (typ == "arg") then
		self:AttackAdd(from);
		-- add recent 4 frequencies
		if (tbl_freq == nil) then
			tbl_freq = {num};
		else
			table.insert(tbl_freq,num);
			if (#tbl_freq == 5) then
				table.remove(tbl_freq,1);
			end
		end
		-- check if immune
		if (#tbl_freq == 4) then
			if (self:FreqPredict() == num) then
				return;
			else -- check saved frequencies
				for var = 1, 4, 1 do
					if (tbl_remember[var] == num) then
						return;
					end
				end
			end
		end
		-- fall apart and fade
		self:Remove();
		local new = self:SpawnX(self:Count(to:GetClass()),"replicator_block");
		self:FadeX(self:Count(to:GetClass()),new);
	end
end

function ENT:FadeX(num,tbl)
	if (num <= 0) then return end
	for var = 1, num, 1 do
		tbl[var].sever = true;
		tbl[var]:OnRemove();
	end
end

function ENT:FreqPredict()
	if (#tbl_freq == 4) then
		local number = nil;
		if (tbl_freq[1] == 1 and tbl_freq[2] == 1 and tbl_freq[3] == 1 and tbl_freq[4] == 1) then
			number = 1;
		elseif (tbl_freq[1] == 2 and tbl_freq[2] == 2 and tbl_freq[3] == 2 and tbl_freq[4] == 2) then
			number = 2;
		elseif (tbl_freq[1] == 3 and tbl_freq[2] == 3 and tbl_freq[3] == 3 and tbl_freq[4] == 3) then	
			number = 3;
		elseif (tbl_freq[1] == 4 and tbl_freq[2] == 4 and tbl_freq[3] == 4 and tbl_freq[4] == 4) then	
			number = 4;
		else
			return 0;
		end
		if (!table.HasValue(tbl_remember,number)) then
			tbl_remember[number] = number;
		end
		return number;
	end
end
