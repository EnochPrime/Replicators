-- this code is used to control the evolution from one form to another
local iCreate = StarGate.CFG:Get("replicator","evolve");
local cost = {};
for k,v in pairs(StarGate.CFG:Get("replicator","cost"):TrimExplode(",")) do
	 cost[k] = v;
end
local c_l = cost[2]/cost[1];
local c_h = cost[3]/cost[1];
local count, tbl, b, l;

function ENT:evolve()
	if not(iCreate) then return end
	local class = self:GetClass();
	if (class == "npc_rep") then
		if (#rep_list == c_l) then -- temporary for testing purposes, official line below
		--if (#rep_list > (c_l + 10) and self:Find("shield_generator") ~= nil and not self:exist("npc_rep_l")) then
			count = c_l;
			b = true;
			for _,v in pairs(rep_list) do
				if (v:GetClass() == "npc_rep") then
					tbl = self:SpawnX(cost[1],"block");
					v:RemoveRep();
					v:Remove();
				end
				if (b) then
					b = false;
					l = tbl[1];
				end
				for _,v in pairs(tbl) do
					v.class = "npc_rep_l";
					v.leader = l;
				end
			end
		end
		if (#rep_list > (c_h + 10) and #attack_list > 0 and not self:exist("npc_rep_h")) then
			count = c_h;
			for k,v in pairs(rep_list) do
				if (v:GetClass() == "npc_rep") then
					return;
				end
			end
		end
	end
	
	if (class == "npc_rep_l") then
		if (#rep_list < 0 or self:Find("shield_generator") == nil) then
			-- disassemble large rep
		end
	end
	
	if (class == "npc_rep_h") then
		if (#rep_list < 0 or #attack_list == 0) then
			-- disassemble human rep
		end
	end
end

function ENT:exist(class)
	local vclass;
	for k,v in pairs(rep_list) do
		vclass = v:GetClass();
		if (vclass == class) then
			return true;
		end
	end
	return false;
end
