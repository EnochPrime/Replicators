local replicators = {};
local attack_list = {};

function ENT:AddReplicators(ent)
	if (attack_list == nil) then
		table.ForceInsert(attack_list,ent);
	else
		for var = 1, #replicators, 1 do
			if (replicators[var] != ent) then
				table.insert(replicators,ent);
			end
		end
	end
end

function ENT:GetReplicators()
	return replicators;
end

function ENT:AddAttacker(ent)
	if (attack_list == nil) then
		table.ForceInsert(attack_list,ent);
	else
		for var = 1, #attack_list, 1 do
			if (attack_list[var] != ent) then
				table.insert(attack_list,ent);
			end
		end
	end
end

function ENT:GetAttacker()
	return attack_list;
end
