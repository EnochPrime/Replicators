AddCSLuaFile("shared.lua");
include("shared.lua");
--SWEP.Sounds = {Shot={Sound("weapons/hd_shot1.mp3"),Sound("weapons/hd_shot2.mp3")}};
SWEP.Frequency = 1;
SWEP.Delay = 5;
SWEP.TimeOut = 0.25; -- Time in seconds, a target will be tracked when hit with the beam

--################### Init the SWEP @ jdm12989
function SWEP:Initialize()
	self:SetWeaponHoldType("shotgun");
end

--################### Initialize the shot @ jdm12989
function SWEP:PrimaryAttack(fast)
	local delay = 0;
	--self.Owner:EmitSound(self.Sounds.Shot[1],90,math.random(96,102));
	self:ShotEffect();
	delay = 0.3;
	self.Weapon:SetNextPrimaryFire(CurTime()+0.8);
	local e = self.Weapon;
	timer.Simple(delay,
		function()
			if(e and e:IsValid() and e.Owner and e.Owner:IsValid()) then
				e:DoShoot();
			end
		end
	);
	return true;
end

--################### Secondary Attack @ aVoN
function SWEP:SecondaryAttack()
	--Change Frequency
	local freqs = 4;
	self.Frequency = math.Clamp((self.Frequency+1) % (freqs + 1),1,freqs);
	self.Owner:SetAmmo(self.Secondary.Ammo,self.Frequency);
	local ammo = self.Owner:GetAmmoCount(self.Secondary.Ammo);
	if(ammo > self.Frequency) then
		self.Owner:RemoveAmmo(ammo-self.Frequency,self.Secondary.Ammo);
	elseif(ammo < self.Frequency) then
		self.Owner:GiveAmmo(1,self.Secondary.Ammo);
	end
end

function SWEP:OwnerChanged() 
	self.Frequency = 1;
end

--################### Do the shot @ jdm12989
function SWEP:DoShoot()
	local p = self.Owner;
	if(not(p and p:IsValid())) then return end;
	local pos = p:GetShootPos();
	local normal = p:GetAimVector();
	-- attack
	--MAKE MORE LINEAR!
	for _,v in pairs(ents.FindInSphere(pos + (100*normal),75)) do
		if (v:GetClass() == "replicator") then
			Msg("Freq = " .. self.Frequency .. "\n");
			v:Disassemble("arg",p,v,self.Frequency);
		end
	end
end

--################### Think @ jdm12989
function SWEP:Think()
	return;
end

--################### Do a push @ jdm12989
function SWEP:ShotEffect()
	local e = self.Owner;
	-- Timer fixes bug, where you cant see your own effect
	timer.Simple(0.1,
		function()
			if(e and e:IsValid()) then
				local fx = EffectData();
				fx:SetEntity(e);
				fx:SetOrigin(e:GetPos());
				util.Effect("arg_shot",fx,true,true);
			end
		end
	);
end
