local replicators = {};
local attack_list = {};

function ENT:AddReplicators(ent)
	if (replicators != nil) then
		for var = 1, #replicators, 1 do
			if (replicators[var] != ent) then
				table.insert(replicators,ent);
			end
		end
	end
end

function ENT:GetReplicators()
	return replicators;
end
