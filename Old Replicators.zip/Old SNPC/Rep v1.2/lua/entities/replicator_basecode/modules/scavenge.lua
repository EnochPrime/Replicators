-- make this find.lua

include('vars.lua');

local trgts = nil;
local maxdist = 0;
local closest = nil;

function ENT:FindMat()
	-- might need to make exceptions
	trgts = ents.FindByClass("prop_physics");
	maxdist = 1000;
	closest = nil;
	if (!trgts or #trgts == 0) then
		--self.scavenge = false;
		return nil;
	else
		for var = 1, #trgts, 1 do
			local dist = (self:GetPos()-trgts[var]:GetPos()):Length(); 
			if (dist < maxdist) then
				maxdist = dist;
				closest = trgts[var];
			end
		end
	end
	
	--[[ make the collective move toward it
	--self.scavenge = true;
	local reps = self:GetReplicators();
	for var = 1, #reps, 1 do
		--if (!reps[var].scavenge) then
			--self.scavenge = true;
			reps[var]:StartSchedule(self:Move(closest));
		--end
	end]]
	return closest;
end

function ENT:FindTech()
	trgts = ents.FindByClass("shield_generator");
	maxdist = 10000;
	closest = nil;
	if (!trgts and #trgts != 0) then
		return nil;
	else
		for var = 1, #trgts, 1 do
			local dist = (self:GetPos()-trgts[var]:GetPos()):Length();
			if (dist < maxdist) then
				maxdist = dist;
				closest = trgts[var];
			end
		end
	end
	return closest;
end
