AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
include('shared.lua');
include('modules/move.lua');

function ENT:Initialize()

	self:SetModel("models/headcrab.mdl");
	self:SetHullType(HULL_TINY);
	self:SetHullSizeNormal();
	self:SetSolid(SOLID_BBOX);
	self:SetMoveType(MOVETYPE_STEP);
	self:CapabilitiesAdd(CAP_MOVE_GROUND);
	self:SetMaxYawSpeed(5000);
	self:SetHealth(100);
  
end
  
function ENT:OnTakeDamage(dmg)
	self:SetHealth(self:Health() - dmg:GetDamage())
	if self:Health() <= 0 then --run on death
		Msg("Dead\n");
		self:SetSchedule( SCHED_FALL_TO_GROUND ) --because it's given a new schedule, the old one will end.
	end
end
  
---------------------------------------------------------
--Name: SelectSchedule
---------------------------------------------------------
function ENT:SelectSchedule()
	Msg("running schdFollow\n");
	self:StartSchedule(self:Follow());
end
