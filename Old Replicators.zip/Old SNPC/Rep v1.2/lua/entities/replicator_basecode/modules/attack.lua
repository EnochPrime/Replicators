include('vars.lua');

local list = nil;

function ENT:AttackCode()
	list = self:GetAttacker();
	if (list and #list > 0) then
		self.attack = true;
		--self.scavenge = false;
	end
end

function ENT:AttackWho()
	list = self:GetAttacker();
	if (#list != 0) then
		return list[math.random(1,#list)];
	end
end
