ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Replicator Base"
ENT.Author			= "JDM12989"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false

ENT.attack_list = {};
