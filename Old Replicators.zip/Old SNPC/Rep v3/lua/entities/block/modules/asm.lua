include('mod2.lua');
local b_c = {};
local b_n, d, d_max, pos;
local cost = {};
for k,v in pairs(StarGate.CFG:Get("replicator","cost"):TrimExplode(",")) do
	 cost[k] = v+0;
end

function ENT:Assemble()
	if (self.class == "npc_rep") then
		self.cost = cost[1];
	elseif (self.class == "npc_rep_l") then
		self.cost = cost[2];
	elseif (self.class == "npc_rep_h") then
		self.cost = cost[3];
	else
		return;
	end
	pos = self:GetPos();
	d_max = 20;
	b_n = ents.FindInSphere(pos,d_max);
	if (b_n == nil or #b_n == 0) then return end
	for _,v in pairs(b_n) do
		if (v:GetClass() == "block" and not v.sever) then
			d = (v:GetPos()-pos):Length();
			if (d < d_max) then
				table.insert(b_c,v);
			end
		end
	end
	if (b_c == nil or #b_c < self.cost or not self.assembled) then return end
	self:SpawnX(1,self.class);
	for i=1,self.cost,1 do
		v.assembled = true;
		v:Remove();
	end
end

function ENT:Gather()
	if (self.leader == nil or not self.leader:IsValid()) then return end
	pos = self:GetPos();
	local d = (self.leader:GetPos()-pos);
	if (d:Length() > 10) then
		local vec = d:Normalize()*50;
		self:GetPhysicsObject():ApplyForceCenter(vec);
		return true;
	end
	return false;
end
