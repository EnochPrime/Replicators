AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
include('shared.lua');
include('modules/group.lua');
  
function ENT:OnTakeDamage(dmg)
	local att = dmg:GetAttacker();
	local dam = dmg:GetDamage();
	self:SetHealth(self:Health() - dam);
	if (self:Health() <= 0) then
		self:RemoveRep(self);
		self:Remove();
		-- half the blocks if shot or explosion under 100 damage or crossbow which = 100
		-- otherwise it is completely destroyed
		if (dmg:IsBulletDamage() or (dmg:IsExplosionDamage() and dam < 100) or dam == 100) then
			self:SpawnX(cost[2]/2,"replicator_block");
		end
		self:GroupDisband();
	end
	-- makes the group attack
	self:GroupAttack(att);
end

function ENT:SelectSchedule()
	local dist = 0;
	local ent = self:Find("shield_generator");
	if (ent ~= nil and ent:IsValid() and ent:Enabled()) then
		dist = ent.Shield.Size + 50;
	end
	self:StartSchedule(self:Move(ent,dist));
end

function ENT:Think()
	-- gather a group of replicators to follow
	self:Check();
	
	-- make all replicators in group follow
	for var = 1, #group, 1 do
		if (group[var] ~= nil and group[var]:IsValid()) then
			group[var]:StartSchedule(self:Move(self,75));
		else
			table.remove(group,var);
		end
	end
end
