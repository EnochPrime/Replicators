-- might end up varying with type, in which case should be put in each type
-- needed in move.lua !

include('spawner.lua');

function ENT:Activity(ent)
	Msg("Activity\n");
	local class = ent:GetClass();
	if (class == "player") then
		-- hurt
		Msg("hurt\n");
		ent:TakeDamage(1,self);
	elseif (class == "prop_physics") then
		-- makes an explosion at the end
		gcombat.devhit(ent,10,20,true);
		--material increase
		self.material = self.material + 10;
		if (self.material >= 100) then
			Msg("enough\n");
			-- replication code, temp!
			self:SpawnX(1,"replicator_standard");
			self.material = self.material - 100;
		end
	-- shouldn't do this unless large type
	elseif (class == "shield_generator") then
		RD_SupplyResource(self, "energy", 100000000);
		if (!self.shield) then
			self.shield = true;
			ent:TriggerInput("Activate",0);
			self:AutoLink(self,ent);
			ent:SetMultiplier(5);
			ent:TriggerInput("Activate",1);
		end
	else
		return;
	end
end

-- from avon stargate_base_tool.lua
function ENT:AutoLink(e1,e2)
	-- Is resource distribution installed?
	if(Dev_Link and e1 and e2 and e1:IsValid() and e2:IsValid() and e1 ~= e2) then
		-- First is for RD1, second for RD2
		local e1_res = e1.resources or e1.resources2;
		local e2_res = e2.resources or e2.resources2;
		if(e1_res and e2_res) then
			-- Devices needs that power?
			local match = false;
			for _,res1 in pairs(e1_res) do
				for _,res2 in pairs(e2_res) do
					if (res1.res_ID == res2.res_ID) then
						match = true;
						break;
					end
				end
				if(match) then break end;
			end
			if(not match) then return end;
			-- Devide already linked with that (Normally not, but just to be sure)?
			for _,res in pairs(e1_res) do
				for _,v in pairs(res.links) do
					if (e2 == v.ent) then
						return;
					end
				end
			end
			-- Create an invisible link
			Dev_Link(e1,e2,e1:GetPos(),e2:GetPos(),"cable/cable2",Color(0,0,0,0),0);
		end
	end
end
