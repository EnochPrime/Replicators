include('vars.lua');

function ENT:AddAttacker(ent)
	table.ForceInsert(attack_list,ent);
	self:AttackCode();
end

function ENT:AttackCode()
	if (attack_list and #attack_list > 0) then
		self.attack = true;
		self.scavenge = false;
	end
end

function ENT:AttackWho()
	if (#attack_list != 0) then
		return attack_list[math.random(1,#attack_list)];
	end
end
