-- Kill Icon
if(file.Exists("../materials/weapons/arg_killicon.vmt")) then
	killicon.Add("weapon_arg","weapons/arg_killicon",Color(255,255,255));
end
