AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
include('shared.lua');
  
function ENT:OnTakeDamage(dmg)
	self:SetHealth(self:Health() - dmg:GetDamage())
	if self:Health() <= 0 then --run on death
		Msg("Dead\n");
		self:SetSchedule( SCHED_FALL_TO_GROUND ) --because it's given a new schedule, the old one will end.
	end
	local attacker = dmg:GetAttacker();
	if (attacker:GetClass() == "player") then
		self:AddAttacker(attacker);
		self:AttackCode();
	end
end
  
function ENT:SelectSchedule()
	--local str = self:Command();
	--Msg("Replicator is performing " .. str .. "\n");
	if (self.attack) then --attack is not working!!
		self:StartSchedule(self:Move(self:AttackWho()));
	else
		self:StartSchedule(self:Move(self:FindMat()));
	end
end
