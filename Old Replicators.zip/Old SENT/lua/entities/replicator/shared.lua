ENT.Type 			= "anim"
ENT.Base 			= "replicator_base"
ENT.PrintName		= "Replicator"
ENT.Author			= "JDM12989"

ENT.Spawnable			= true
ENT.AdminSpawnable		= true

ENT.model = "models/Combine_Helicopter/helicopter_bomb01.mdl";
