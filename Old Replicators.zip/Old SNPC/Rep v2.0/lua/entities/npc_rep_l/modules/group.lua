group = {};
amt = 2;

function ENT:Check()
	if (#group < amt) then
		self:AddParty();
	end
	Msg(table.ToString(group,"Group",false));
	Msg("\n");
end

function ENT:AddParty()
	local t = self:GetReps();
	local add = true;
	if (#group == 0) then
		if (t[1]:GetClass() == "npc_rep") then
			table.insert(group,t[1]);
		end
	elseif (#group == amt) then
		return;
	else
		local num = 0;
		if (amt > #t) then
			num = #t;
		else
			num = amt;
		end
		-- continue until the group as max members
		for int = 2, num, 1 do
			-- go through the list of reps
			local index = math.random(1,#t);
			-- if current rep is a normal one then...
			if (t[index]:GetClass() == "npc_rep") then
				-- go through group
				for var = 1, #group, 1 do
					add = true;
					-- if current rep isn't already a groupy
					if (group[var] == t[index]) then
						add = false;
					end
				end
				if (add) then
					table.insert(group,t[index]);
					t[index].leader = self;
				end
			end
		end
	end
end

function ENT:GroupAttack(ent)
	for var = 1, #group, 1 do
		group[var]:AddAttacker(ent);
	end
end

function ENT:GroupDisban()
	for var = 1, #group, 1 do
		group[var].leader = nil;
	end
end
