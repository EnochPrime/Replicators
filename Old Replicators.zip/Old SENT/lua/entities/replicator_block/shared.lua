ENT.Type 			= "anim"
ENT.Base 			= "replicator_base"
ENT.PrintName		= "Replicator Block"
ENT.Author			= "JDM12989"

ENT.Spawnable			= true;
ENT.AdminSpawnable		= true;

ENT.model = "models/props_junk/popcan01a.mdl";