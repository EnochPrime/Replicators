AddCSLuaFile("shared.lua");
include('shared.lua');
--include('modules/logic.lua');
include('modules/attack.lua');
include('modules/activity.lua');
include('modules/move.lua');
include('modules/scavenge.lua');
include('modules/spawner.lua');
include('modules/vars.lua');

function ENT:Initialize()

	self:SetModel(self.model);
	self:SetHullType(HULL_TINY);				--needs to vary
	self:SetHullSizeNormal();
	self:SetSolid(SOLID_BBOX);
	self:SetMoveType(MOVETYPE_STEP);
	self:CapabilitiesAdd(CAP_MOVE_GROUND);
	self:SetMaxYawSpeed(5000);
	self:SetHealth(100);						--needs to vary
	self:AddReplicators(self);
	self.scavenge = false;
	self.attack = false;
	self.material = 0;
	self.shield = false;
	LS_RegisterEnt(self);
	RD_AddResource(self, "energy", 100000000);
  
end
