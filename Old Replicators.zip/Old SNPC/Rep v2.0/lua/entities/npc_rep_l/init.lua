AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
include('shared.lua');
include('modules/group.lua');
  
function ENT:OnTakeDamage(dmg)
	local att = dmg:GetAttacker();
	local dam = dmg:GetDamage();
	self:SetHealth(self:Health() - dam);
	if (self:Health() <= 0) then
		self:RemoveRep(self);
		self:Remove();
		-- half the blocks if shot or explosion under 100 damage or crossbow which = 100
		-- otherwise it is completely destroyed
		if (dmg:IsBulletDamage() or (dmg:IsExplosionDamage() and dam < 100) or dam == 100) then
			self:SpawnX(cost[2]/2,"replicator_block");
		end
		self:GroupDisban();
	end
	-- makes the group attack
	self:GroupAttack(att);
end

function ENT:SelectSchedule()
	-- gather a party of replicators to follow
	self:Check();
	-- modify to go after shields/zpm and increase power output
	self:StartSchedule(self:Move(self:Find("shield_generator")));
end

function ENT:Think()
	for var = 1, #group, 1 do
		if (group[var] ~= nil and group[var]:IsValid()) then
			group[var]:StartSchedule(self:Move(self));
		else
			table.remove(group,var);
		end
	end
end
