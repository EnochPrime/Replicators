include('activity.lua');
local schdFollow = ai_schedule.New();

function ENT:Move(ent)
	schdFollow = ai_schedule.New();
	if (ent != nil) then
		schdFollow:AddTask("Follow",{Class = ent:GetClass()});
		schdFollow:EngTask("TASK_GET_PATH_TO_LASTPOSITION",0);
		schdFollow:EngTask("TASK_FACE_PATH",0);
		schdFollow:EngTask("TASK_RUN_PATH",0);
		schdFollow:AddTask("WaitCustom");
	else 
		schdFollow:EngTask("TASK_WAIT",0);
		--schdFollow:EngTask("TASK_WANDER",0); -- bugs out
	end
	return schdFollow;
end

function ENT:Task_Follow(data)
	-- check if the leader is still valid and < 50 away (if so, stop moving and perform activity)
	-- doesn't work with bigger objects, need to do a traceline
	if (!self.follow:IsValid() or self.follow == nil) then
		return;
	else
		local trace = util.QuickTrace(self:GetPos(),self:GetAimVector()*50,self);
		if ((self:GetPos()-self.follow:GetPos()):Length() < 50 or trace.Entity == self.follow) then
			self:Activity(self.follow);
		end
	end
end

function ENT:TaskStart_Follow(data)
	self:TaskComplete();
	-- obtain a new location to move to
	local leader = ents.FindByClass(data.Class);
	for _,v in pairs (leader) do
		if (v:IsValid()) then
			self.lp = v:GetPos();
			self:SetLastPosition(self.lp + Vector(0,0,25));
			self.follow = v;
		end
	end
end

-- wait until object being followed is moved
function ENT:Task_WaitCustom(data)
	if (!self.follow:IsValid() or self.follow == nil) then
		self:TaskComplete();
	elseif (self.lp ~= self.follow:GetPos() or(self:GetPos()-self.follow:GetPos()):Length() < 50) then
		self:TaskComplete();
	end
end

function ENT:TaskStart_WaitCustom(data)
end
