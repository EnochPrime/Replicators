local stargate = false;
local dialing = false;

function ENT:GateDial()
	local gates = ents.FindByClass("stargate_sg1")[1]:GetAllGates(false);
	local maxdist = 100000000;
	local object = nil;
	
	for k,v in pairs(gates) do
		local vdist = (v:GetPos() - self:GetPos()):Length();
		if (vdist < maxdist) then
			maxdist = vdist;
			closest = v;
		end
	end
	
	if (closest != nil and closest:IsValid()) then
		local vec = ((closest:GetPos()-self.Entity:GetPos()):Normalize()*self.speed)
		self.Entity:GetPhysicsObject():ApplyForceCenter(vec);
	end
	
	if ((closest:GetPos()-self:GetPos()):Length()  < 20 and !dialing) then
		local dgate = gates[math.random(1, #gates)];
		if (dgate == closest) then
			return;
		else
			dialing = true;
			stargate = false;
			local address = "address_" .. dgate:GetName() .. "#";
			closest:AcceptInput(address,self,self);
			closest:AcceptInput("call_dhd",self,self);
		end
	end
	
end

function ENT:ActivateDialling(bool)
	stargate = bool;
end

function ENT:Dial()
	return stargate;
end
