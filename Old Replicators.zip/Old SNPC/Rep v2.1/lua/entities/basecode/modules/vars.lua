cost = {20,200,2000}; -- attach this to a config file eventually
rep_list = {};
attack_list = {};

function ENT:AddRep(ent)
	if (#rep_list == 0 and ent:GetClass() == "npc_rep") then
		table.insert(rep_list,ent);
	else
		for var = 1, #rep_list, 1 do
			if (rep_list[var] == ent or ent:GetClass() ~= "npc_rep") then
				return;
			end
		end
		table.insert(rep_list,ent);
	end
end

function ENT:RemoveRep(ent)
	for var = 1, #rep_list, 1 do
		if (rep_list[var] == ent) then
			table.remove(rep_list,var);
		end
	end
end

function ENT:GetReps()
	return rep_list;
end

-- below is all the functions nessacary for attacking
function ENT:AddAttacker(ent)
	if (#attack_list == 0) then
		table.insert(attack_list,ent);
	else
		for var = 1, #attack_list, 1 do
			if (attack_list[var] != ent) then
				table.insert(attack_list,ent);
			end
		end
	end
	self:AttackCode();
end

function ENT:RemoveAttacker(ent)
	for var = 1, #attack_list, 1 do
		if (attack_list[var] == ent) then
			table.remove(attack_list,var);
		end
	end
	self:AttackCode();
end

function ENT:AttackCode(str,tbl)
	if (str == nil) then
		if (#attack_list > 0) then
			self.attack = true;
			for var = 1, #rep_list, 1 do
				if (math.random(0,1) == 1) then
					rep_list[var].attack = true;
				end
			end
		else
			for var = 1, #rep_list, 1 do
				rep_list[var].attack = false;
			end
		end
	elseif (str == "lead") then
		for var = 1, #tbl, 1 do
			tbl[var].attack = true;
		end
	else
		return;
	end
end

function ENT:AttackWho()
	if (#attack_list == 0) then
		return;
	else
		local num = math.random(1,#attack_list);
		return attack_list[num];
	end
end
