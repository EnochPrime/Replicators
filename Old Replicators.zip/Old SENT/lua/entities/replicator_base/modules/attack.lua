-- make so it doesn't keep switching between attackers
function ENT:Attack()	
	if (self.attack_list == {} or #self.attack_list == 0) then
		self:AttackCode(false);
	else
		local num = math.random(1, #self.attack_list);
		local temp = self.attack_list[num];
		if (temp:IsValid() and temp:Alive()) then
			local vec = ((temp:GetPos()-self:GetPos()):Normalize()*(self.speed*1.5))
			self:GetPhysicsObject():ApplyForceCenter(vec);
		else
			table.remove(self.attack_list,num);
		end
	end
end

function ENT:AttackAdd(attacker)
	if (attacker:IsPlayer()) then
		if (self:AttackerCheck(attacker)) then
			table.insert(self.attack_list,attacker);
		end
		self:AttackCode(true);
	end
end

function ENT:AttackerCheck(ent)
	if (self.attack_list != {} and #self.attack_list != 0) then
		for _,v in pairs(self.attack_list) do
			if (v == ent) then
				return false;
			end
		end
	end
	return true;
end

function ENT:AttackCode(bool)
	local replicators = ents.FindByClass("replicator");
	if (bool) then
		for _,v in pairs(replicators) do
			if (math.random(0,1) == 1) then
				v.attack = true;
			end
		end
	else
		for _,v in pairs(replicators) do
			v.attack = false;
		end
	end
end
