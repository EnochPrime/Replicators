AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");
include('shared.lua');

function ENT:SpawnFunction(ply, tr)
	if (!tr.Hit) then return end
	local SpawnPos = tr.HitPos + tr.HitNormal * 16;
	local ent = ents.Create("replicator_block");
	ent:SetPos(SpawnPos);
	ent:Spawn();
	ent:Activate();
	ent:SetCollisionGroup(COLLISION_GROUP_DEBRIS);
	return ent;
end

function ENT:Think()
	if (self.ThinkNext > CurTime()) then return end
	if (self.sever) then return end
	self:Gather();
	self:Assemble("npc_rep");
	self.NextThink = CurTime()+1;
end

function ENT:OnRemove()
	self:SetNWBool("fade_out",true);
	-- Kill after some time
	local e = self.Entity;
	timer.Simple(5,
	function()
		if(e and e:IsValid()) then
			self:Remove();
		end
	end
	);
end

function ENT:OnTakeDamage(dmg)
	self.health = self.health - dmg:GetDamage();
	if (self.health <= 0) then
		self:Remove();
	end
end
