include('vars.lua');

function ENT:FindMat()
	local trgts = ents.FindByClass("prop_physics");
	local maxrange = 1000;
	local closest = nil;
	if (!trgts or #trgts == 0) then
		--self.scavenge = false;
		return nil;
	else
		for var = 1, #trgts, 1 do
			local dist = (self:GetPos()-trgts[var]:GetPos()):Length(); 
			if (dist < maxrange) then
				maxdist = dist;
				closest = trgts[var];
			end
		end
	end
	
	--[[ make the collective move toward it
	--self.scavenge = true;
	local reps = self:GetReplicators();
	for var = 1, #reps, 1 do
		--if (!reps[var].scavenge) then
			--self.scavenge = true;
			reps[var]:StartSchedule(self:Move(closest));
		--end
	end]]
	return closest;
end
