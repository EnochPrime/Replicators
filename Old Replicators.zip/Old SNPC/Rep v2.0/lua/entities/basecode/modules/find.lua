include('vars.lua');

function ENT:Find(str)
	local t = nil;
	local m_d = 0;
	local c = nil;
	
	t = ents.FindByClass(str);
	m_d = 10000;
	if (t and #t > 0) then
		for var = 1, #t, 1 do
			local dist = (self:GetPos()-t[var]:GetPos()):Length(); 
			if (dist < m_d) then
				m_d = dist;
				c = t[var];
			end
		end
	end
	return c;
end
