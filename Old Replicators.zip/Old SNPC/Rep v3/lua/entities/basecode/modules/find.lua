local except = StarGate.CFG.Get("replicator","exceptions") or {" "};

function ENT:Find(class)
	local pos = self:GetPos();
	local dist = 0;
	local d = 10000;
	local t = ents.FindInSphere(pos,d);
	local c = nil;
	for _,v in pairs(except) do
		if (v == class) then
			return nil;
		end
	end
	if (t and #t > 0) then
		for _,v in pairs(t) do
			if (v:GetClass() == class) then
				local color = {v:GetColor()};
				if (color[4] == 255) then
					dist = (pos-v:GetPos()):Length(); 
					if (dist < d) then
						d = dist;
						c = v;
					end
				end
			end
		end
	end
	return c;
end
